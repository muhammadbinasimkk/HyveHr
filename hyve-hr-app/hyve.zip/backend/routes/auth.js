// routes/auth.js
const express = require('express');
const { registerUser, loginUser } = require('../controllers/authController');
const { body, validationResult } = require('express-validator');
const { authMiddleware, roleAuthorization } = require('../middleware/authMiddleware');

const router = express.Router();

// Register User
router.post('/register', [
    body('firstName').not().isEmpty().withMessage('First name is required'),
    body('lastName').not().isEmpty().withMessage('Last name is required'),
    body('email').isEmail().withMessage('Enter a valid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    registerUser(req, res);
});

// Login User
router.post('/login', [
    body('email').isEmail().withMessage('Enter a valid email'),
    body('password').exists().withMessage('Password is required'),
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    loginUser(req, res);
});

// Protected route for Admin only
router.get('/admin', authMiddleware, roleAuthorization('Admin'), (req, res) => {
    res.json({ message: 'Welcome, Admin!' });
});

// Protected route for Owner only
router.get('/owner', authMiddleware, roleAuthorization('Owner'), (req, res) => {
    res.json({ message: 'Welcome, Owner!' });
});

module.exports = router;
