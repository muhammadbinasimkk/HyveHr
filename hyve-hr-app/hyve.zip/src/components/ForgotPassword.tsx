// src/components/ForgotPassword.tsx
import React from 'react';
import { Link } from 'react-router-dom';

const ForgotPassword: React.FC = () => {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Forgot Password</h2>
        {/* Implement forgot password form here */}
        <p className="text-gray-700">Forgot password functionality is not implemented yet.</p>
        <Link to="/" className="mt-4 inline-block text-blue-500 hover:underline">
          Back to Login
        </Link>
      </div>
    </div>
  );
};

export default ForgotPassword;
