// src/components/Login.tsx
import React, { useState } from 'react';
import { FaEnvelope, FaLock } from 'react-icons/fa';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

const Login: React.FC = () => {
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const initialValues = {
    email: '',
    password: '',
  };

  const validationSchema = Yup.object({
    email: Yup.string().email('Invalid email address').required('Email is required'),
    password: Yup.string().required('Password is required').min(6, 'Password must be at least 6 characters'),
  });

  const onSubmit = async (values: typeof initialValues) => {
    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', values);
      // Store token and user information (adjust as per your API response)
      navigate('/home');
    } catch (error) {
      setError('Invalid email or password');
    }
  };

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit,
  });

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 p-4">
      <div className="relative flex flex-col items-center justify-center w-full max-w-md p-8 border border-gray-600 bg-gray-800 shadow-lg">
        <h1 className="text-3xl font-bold text-white mb-6 text-center">Sign In</h1>
        {error && <p className="text-red-500 mb-4">{error}</p>}
        <form onSubmit={formik.handleSubmit} className="w-full space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-white">Email Address</label>
            <div className="flex items-center mt-2">
              <FaEnvelope className="text-gray-400 mr-3" />
              <input
                id="email"
                type="email"
                name="email"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.email}
                placeholder="Enter your email"
                className="w-full py-3 pl-10 pr-4 bg-gray-700 text-white border border-gray-600"
              />
            </div>
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-white">Password</label>
            <div className="flex items-center mt-2">
              <FaLock className="text-gray-400 mr-3" />
              <input
                id="password"
                type="password"
                name="password"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.password}
                placeholder="Enter your password"
                className="w-full py-3 pl-10 pr-4 bg-gray-700 text-white border border-gray-600"
              />
            </div>
          </div>
          <div className="flex justify-between items-center mt-4 text-sm">
            <Link to="/forgot-password" className="text-white hover:underline">Forgot Password?</Link>
            <Link to="/register" className="text-white cursor-pointer hover:underline">Register</Link>
          </div>
          <button
            type="submit"
            className="w-full bg-green-600 text-white py-3 font-semibold hover:bg-green-500 transition duration-300 text-lg"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
