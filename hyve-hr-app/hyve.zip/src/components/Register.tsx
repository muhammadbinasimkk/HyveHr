// src/components/Register.tsx
import React, { useState } from 'react';
import { FaEnvelope, FaLock, FaUser, FaBuilding } from 'react-icons/fa';
import { useFormik, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

interface RegisterFormValues {
  firstName: string;
  lastName: string;
  companyName: string;
  jobTitle: 'employer' | 'employee';
  email: string;
  password: string;
  confirmPassword: string;
}

const Register: React.FC = () => {
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const initialValues: RegisterFormValues = {
    firstName: '',
    lastName: '',
    companyName: '',
    jobTitle: 'employee', // Default value
    email: '',
    password: '',
    confirmPassword: '',
  };

  const validationSchema = Yup.object({
    firstName: Yup.string().required('First Name is required'),
    lastName: Yup.string().required('Last Name is required'),
    companyName: Yup.string().required('Company Name is required'),
    jobTitle: Yup.string().oneOf(['employer', 'employee'], 'Job Title is required').required('Job Title is required'),
    email: Yup.string().email('Invalid email address').required('Email is required'),
    password: Yup.string()
      .required('Password is required')
      .min(6, 'Password must be at least 6 characters'),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref('password')], 'Passwords must match')
      .required('Please confirm your password'),
  });

  const onSubmit = async (
    values: RegisterFormValues,
    { setSubmitting }: FormikHelpers<RegisterFormValues>
  ) => {
    setError(null); // Clear previous error
    try {
      const response = await axios.post('http://localhost:5000/api/auth/register', values);
      if (response.status === 200 || response.status === 201) {
        navigate('/login');
      }
    } catch (error: any) {
      console.error('Registration failed:', error);
      setError(error?.response?.data?.message || 'Failed to register'); // Capture detailed error from server
      setSubmitting(false);
    }
  };

  const formik = useFormik<RegisterFormValues>({
    initialValues,
    validationSchema,
    onSubmit,
  });

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 p-2">
      <div className="relative flex flex-col items-center justify-center w-full max-w-2xl p-4 border border-gray-600 bg-gray-800 shadow-lg px-8">
        <h1 className="text-3xl font-bold text-white mb-6 text-center">Register</h1>

        {error && <p className="text-red-500 mb-4">{error}</p>}

        <form onSubmit={formik.handleSubmit} className="w-full grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* First Name Field */}
          <div className="relative">
            <label htmlFor="firstName" className="block text-sm font-medium text-white">
              First Name
            </label>
            <div className="flex items-center mt-2">
              <FaUser className="text-gray-400 mr-3" />
              <input
                id="firstName"
                type="text"
                name="firstName"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.firstName}
                placeholder="Enter your first name"
                className="w-full py-2 pl-10 pr-4 bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            {formik.touched.firstName && formik.errors.firstName ? (
              <p className="text-red-500 text-sm mt-2">{formik.errors.firstName}</p>
            ) : null}
          </div>

          {/* Last Name Field */}
          <div className="relative">
            <label htmlFor="lastName" className="block text-sm font-medium text-white">
              Last Name
            </label>
            <div className="flex items-center mt-2">
              <FaUser className="text-gray-400 mr-3" />
              <input
                id="lastName"
                type="text"
                name="lastName"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.lastName}
                placeholder="Enter your last name"
                className="w-full py-2 pl-10 pr-4 bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            {formik.touched.lastName && formik.errors.lastName ? (
              <p className="text-red-500 text-sm mt-2">{formik.errors.lastName}</p>
            ) : null}
          </div>

          {/* Company Name Field */}
          <div className="relative">
            <label htmlFor="companyName" className="block text-sm font-medium text-white">
              Company Name
            </label>
            <div className="flex items-center mt-2">
              <FaBuilding className="text-gray-400 mr-3" />
              <input
                id="companyName"
                type="text"
                name="companyName"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.companyName}
                placeholder="Enter your company name"
                className="w-full py-2 pl-10 pr-4 bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            {formik.touched.companyName && formik.errors.companyName ? (
              <p className="text-red-500 text-sm mt-2">{formik.errors.companyName}</p>
            ) : null}
          </div>

         
          {/* Email Field */}
          <div className="relative">
            <label htmlFor="email" className="block text-sm font-medium text-white">
              Work Email
            </label>
            <div className="flex items-center mt-2">
              <FaEnvelope className="text-gray-400 mr-3" />
              <input
                id="email"
                type="email"
                name="email"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.email}
                placeholder="Enter your email"
                className="w-full py-2 pl-10 pr-4 bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            {formik.touched.email && formik.errors.email ? (
              <p className="text-red-500 text-sm mt-2">{formik.errors.email}</p>
            ) : null}
          </div>

          {/* Password Field */}
          <div className="relative">
            <label htmlFor="password" className="block text-sm font-medium text-white">
              Password
            </label>
            <div className="flex items-center mt-2">
              <FaLock className="text-gray-400 mr-3" />
              <input
                id="password"
                type="password"
                name="password"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.password}
                placeholder="Enter your password"
                className="w-full py-2 pl-10 pr-4 bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            {formik.touched.password && formik.errors.password ? (
              <p className="text-red-500 text-sm mt-2">{formik.errors.password}</p>
            ) : null}
          </div>

          {/* Confirm Password Field */}
          <div className="relative">
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-white">
              Confirm Password
            </label>
            <div className="flex items-center mt-2">
              <FaLock className="text-gray-400 mr-3" />
              <input
                id="confirmPassword"
                type="password"
                name="confirmPassword"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.confirmPassword}
                placeholder="Confirm your password"
                className="w-full py-2 pl-10 pr-4 bg-gray-700 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500"
                required
              />
            </div>
            {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
              <p className="text-red-500 text-sm mt-2">{formik.errors.confirmPassword}</p>
            ) : null}
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full py-3 px-6 bg-green-500 text-white font-semibold shadow-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-400"
              disabled={formik.isSubmitting}
            >
              {formik.isSubmitting ? 'Registering...' : 'Register'}
            </button>
          </div>
        </form>

        <p className="mt-4 text-white">
          Already have an account? <Link to="/login" className="text-green-500">Login here</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
