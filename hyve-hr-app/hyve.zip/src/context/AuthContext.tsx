// src/context/AuthContext.tsx
import React, { createContext, useContext, useState, ReactNode } from 'react';
import axios from 'axios';

interface AuthContextType {
  currentUser: any; // Replace 'any' with your user type
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isAuthorized: (role: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<any>(null); // Replace 'any' with your user type

  const login = async (email: string, password: string) => {
    const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });
    setCurrentUser({ ...response.data.user, token: response.data.token }); // Adjust as per your API response
  };

  const logout = async () => {
    setCurrentUser(null);
  };

  const isAuthorized = (role: string) => {
    return currentUser?.role === role; // Check user role
  };

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, isAuthorized }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
